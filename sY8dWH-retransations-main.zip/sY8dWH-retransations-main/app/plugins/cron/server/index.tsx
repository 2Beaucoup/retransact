import { CronService } from './cron.service'

export namespace CronServer {
  export const service = CronService
}
