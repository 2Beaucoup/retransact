export const TemplateWelcome = `
<Card.Header>
  <h2>Welcome to __application.name__</h2>
  <hr />
</Card.Header>

<Card.Body>
  <p>Your account is now active.</p>
</Card.Body>

<Card.Footer>
  <p>Sent by __application.name__</p>
</Card.Footer>
  `.trim()
