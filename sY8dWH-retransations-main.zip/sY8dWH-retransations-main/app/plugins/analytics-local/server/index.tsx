import { trpcRouter } from './trpcRouter'

export const AnalyticsLocalServer = {
  trpcRouter,
}
