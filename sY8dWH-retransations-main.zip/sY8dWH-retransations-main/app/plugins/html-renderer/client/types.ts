export type HtmlRendererProps = {
  content: string
  search?: string
  onNavigate?: (path: string) => void
}
