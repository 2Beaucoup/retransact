import { SocketService } from './service'

export namespace SocketBase {
  export const service = SocketService
}
