import { SocialButtons as AuthenticationSocialButtons } from './SocialButtons'

export namespace AuthenticationClient {
  export const SocialButtons = AuthenticationSocialButtons
}
