/* eslint-disable */
import type { unsetMarker, AnyRouter, AnyRootConfig, CreateRouterInner, Procedure, ProcedureBuilder, ProcedureParams, ProcedureRouterRecord, ProcedureType } from "@trpc/server";
import type { PrismaClient } from "@zenstackhq/runtime/models";
import createUserRouter from "./User.router";
import createPropertyRouter from "./Property.router";
import createClientRouter from "./Client.router";
import createTransactionRouter from "./Transaction.router";
import createTransactionParticipantRouter from "./TransactionParticipant.router";
import createDocumentRouter from "./Document.router";
import createAppointmentRouter from "./Appointment.router";
import createOrganizationRouter from "./Organization.router";
import createOrganizationRoleRouter from "./OrganizationRole.router";
import createPwaSubscriptionRouter from "./PwaSubscription.router";
import { ClientType as UserClientType } from "./User.router";
import { ClientType as PropertyClientType } from "./Property.router";
import { ClientType as ClientClientType } from "./Client.router";
import { ClientType as TransactionClientType } from "./Transaction.router";
import { ClientType as TransactionParticipantClientType } from "./TransactionParticipant.router";
import { ClientType as DocumentClientType } from "./Document.router";
import { ClientType as AppointmentClientType } from "./Appointment.router";
import { ClientType as OrganizationClientType } from "./Organization.router";
import { ClientType as OrganizationRoleClientType } from "./OrganizationRole.router";
import { ClientType as PwaSubscriptionClientType } from "./PwaSubscription.router";

export type BaseConfig = AnyRootConfig;

export type RouterFactory<Config extends BaseConfig> = <
    ProcRouterRecord extends ProcedureRouterRecord
>(
    procedures: ProcRouterRecord
) => CreateRouterInner<Config, ProcRouterRecord>;

export type UnsetMarker = typeof unsetMarker;

export type ProcBuilder<Config extends BaseConfig> = ProcedureBuilder<
    ProcedureParams<Config, any, any, any, UnsetMarker, UnsetMarker, any>
>;

export function db(ctx: any) {
    if (!ctx.prisma) {
        throw new Error('Missing "prisma" field in trpc context');
    }
    return ctx.prisma as PrismaClient;
}

export function createRouter<Config extends BaseConfig>(router: RouterFactory<Config>, procedure: ProcBuilder<Config>) {
    return router({
        user: createUserRouter(router, procedure),
        property: createPropertyRouter(router, procedure),
        client: createClientRouter(router, procedure),
        transaction: createTransactionRouter(router, procedure),
        transactionParticipant: createTransactionParticipantRouter(router, procedure),
        document: createDocumentRouter(router, procedure),
        appointment: createAppointmentRouter(router, procedure),
        organization: createOrganizationRouter(router, procedure),
        organizationRole: createOrganizationRoleRouter(router, procedure),
        pwaSubscription: createPwaSubscriptionRouter(router, procedure),
    }
    );
}

export interface ClientType<AppRouter extends AnyRouter> {
    user: UserClientType<AppRouter>;
    property: PropertyClientType<AppRouter>;
    client: ClientClientType<AppRouter>;
    transaction: TransactionClientType<AppRouter>;
    transactionParticipant: TransactionParticipantClientType<AppRouter>;
    document: DocumentClientType<AppRouter>;
    appointment: AppointmentClientType<AppRouter>;
    organization: OrganizationClientType<AppRouter>;
    organizationRole: OrganizationRoleClientType<AppRouter>;
    pwaSubscription: PwaSubscriptionClientType<AppRouter>;
}
