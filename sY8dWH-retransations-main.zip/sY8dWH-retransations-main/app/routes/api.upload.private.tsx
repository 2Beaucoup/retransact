import { UploadServer } from '../plugins/upload/server'

export const action = UploadServer.actionPrivate
